﻿<#
.SYNOPSIS

PSAppDeployToolkit - Provides the ability to extend and customise the toolkit by adding your own functions that can be re-used.

.DESCRIPTION

This script is a template that allows you to extend the toolkit with your own custom functions.

This script is dot-sourced by the AppDeployToolkitMain.ps1 script which contains the logic and functions required to install or uninstall an application.

PSApppDeployToolkit is licensed under the GNU LGPLv3 License - (C) 2024 PSAppDeployToolkit Team (Sean Lillis, Dan Cunningham and Muhammad Mashwani).

This program is free software: you can redistribute it and/or modify it under the terms of the GNU Lesser General Public License as published by the
Free Software Foundation, either version 3 of the License, or any later version. This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
for more details. You should have received a copy of the GNU Lesser General Public License along with this program. If not, see <http://www.gnu.org/licenses/>.

.EXAMPLE

powershell.exe -File .\AppDeployToolkitHelp.ps1

.INPUTS

None

You cannot pipe objects to this script.

.OUTPUTS

None

This script does not generate any output.

.NOTES

.LINK

https://psappdeploytoolkit.com
#>


[CmdletBinding()]
Param (
)

##*===============================================
##* VARIABLE DECLARATION
##*===============================================

# Variables: Script
[string]$appDeployToolkitExtName = 'PSAppDeployToolkitExt'
[string]$appDeployExtScriptFriendlyName = 'App Deploy Toolkit Extensions'
[version]$appDeployExtScriptVersion = [version]'3.10.1'
[string]$appDeployExtScriptDate = '05/03/2024'
[hashtable]$appDeployExtScriptParameters = $PSBoundParameters

##*===============================================
##* FUNCTION LISTINGS
##*===============================================

# <Your custom functions go here>

$KeyName = $("$appVendor-$appName-$appVersion-$appRevision".Replace(' ',''))

Function Copy-UserFileSettings {
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $True)]
		[ValidateNotNullOrEmpty()]
		[String]$Source,
		[Parameter(Mandatory = $True)]
		[ValidateNotNullOrEmpty()]
		[String]$Destination
	)
	$Profiles = Get-UserProfiles
	ForEach ($Profile In $Profiles) {
		$FullSourcePath = $dirFiles + '\UserFileSettings\' + $Source
		$FullDestinationPath = $Profile.ProfilePath + '\' + $Destination
		Copy-File -Path $FullSourcePath -Destination $FullDestinationPath -Recurse
	}
}

Function Test-Windows10MS {
	$Result = Get-WmiObject -Query "SELECT Version, OperatingSystemSKU FROM Win32_OperatingSystem"
	If (($Result.Version -like "10.0*") -and ($Result.OperatingSystemSKU -eq "175")) {
		Return $True
	}
	Else {
		Return $False
	}
}

Function Initialize-PackageStatusLog {
	If (-not (Test-Path -Path "HKLM:\SOFTWARE\PSADT\Log")) {
		New-Item -Path "HKLM:\SOFTWARE\PSADT" -Name "Log" -Force
	}
	If (-not (Test-Path -Path "HKLM:\SOFTWARE\PSADT\Log\$KeyName")) {
		New-Item -Path "HKLM:\SOFTWARE\PSADT\Log\$KeyName"
	}
	New-ItemProperty -Path "HKLM:\SOFTWARE\PSADT\Log\$KeyName" -Name "Vendor" -Value $("$appVendor".Replace(' ','')) -Force
	New-ItemProperty -Path "HKLM:\SOFTWARE\PSADT\Log\$KeyName" -Name "ApplicationName" -Value $("$appName".Replace(' ','')) -Force
	New-ItemProperty -Path "HKLM:\SOFTWARE\PSADT\Log\$KeyName" -Name "Version" -Value $("$appVersion".Replace(' ','')) -Force
	New-ItemProperty -Path "HKLM:\SOFTWARE\PSADT\Log\$KeyName" -Name "Build" -Value $("$appRevision".Replace(' ','')) -Force
	New-ItemProperty -Path "HKLM:\SOFTWARE\PSADT\Log\$KeyName" -Name "Status" -Value "Unknown" -Force
}

Function Write-PackageStatusLog {
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory=$True)]
		[ValidateNotNullOrEmpty()]
		[String]$Status
	)
	Set-ItemProperty -Path "HKLM:\SOFTWARE\PSADT\Log\$KeyName" -Name "Status" -Value $Status -Force
}

Function Remove-PackageStatusLog {
	If (Test-Path "HKLM:\SOFTWARE\PSADT\Log\$KeyName") {
		Remove-Item -Path "HKLM:\SOFTWARE\PSADT\Log\$KeyName" -Force -Recurse
	}
}

##*===============================================
##* END FUNCTION LISTINGS
##*===============================================

##*===============================================
##* SCRIPT BODY
##*===============================================

If ($scriptParentPath) {
    Write-Log -Message "Script [$($MyInvocation.MyCommand.Definition)] dot-source invoked by [$(((Get-Variable -Name MyInvocation).Value).ScriptName)]" -Source $appDeployToolkitExtName
}
Else {
    Write-Log -Message "Script [$($MyInvocation.MyCommand.Definition)] invoked directly" -Source $appDeployToolkitExtName
}

##*===============================================
##* END SCRIPT BODY
##*===============================================
